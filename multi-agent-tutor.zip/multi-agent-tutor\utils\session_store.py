"""
会话持久化工具：保存/加载学习进度
"""

from __future__ import annotations
import json
import os
import uuid
import datetime
from pathlib import Path
from dataclasses import asdict

from utils.shared import (
    SessionState, AgentContext, KnowledgeState,
    LearningPath, LearningStep, FeedbackReport,
    AnswerRecord
)

DATA_DIR = Path(__file__).parent.parent / "data"
DATA_DIR.mkdir(exist_ok=True)


def new_session(context: AgentContext) -> SessionState:
    """创建新会话"""
    return SessionState(
        session_id=str(uuid.uuid4())[:8],
        context=context
    )


def save_session(session: SessionState) -> str:
    """保存会话到JSON文件"""
    session.updated_at = datetime.datetime.now().isoformat()
    path = DATA_DIR / f"session_{session.session_id}.json"

    # 转换为可序列化格式
    data = _session_to_dict(session)

    with open(path, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    return str(path)


def load_session(session_id: str) -> SessionState | None:
    """从文件加载会话"""
    path = DATA_DIR / f"session_{session_id}.json"
    if not path.exists():
        return None

    with open(path, "r", encoding="utf-8") as f:
        data = json.load(f)

    return _dict_to_session(data)


def list_sessions() -> list[dict]:
    """列出所有保存的会话"""
    sessions = []
    for f in DATA_DIR.glob("session_*.json"):
        with open(f, "r", encoding="utf-8") as fp:
            data = json.load(fp)
            sessions.append({
                "session_id": data.get("session_id"),
                "created_at": data.get("created_at"),
                "updated_at": data.get("updated_at"),
                "completed_topics": data.get("completed_topics", []),
                "student": data.get("context", {}).get("student_grade", "?")
            })
    return sorted(sessions, key=lambda x: x["updated_at"], reverse=True)


def append_answer_history(session: SessionState, topic: str, question: str, correct: bool):
    """向会话追加答题记录"""
    session.context.answer_history.append({
        "topic": topic,
        "question": question,
        "correct": correct,
        "timestamp": datetime.datetime.now().isoformat()
    })


# ─── 序列化辅助 ───────────────────────────────

def _session_to_dict(s: SessionState) -> dict:
    d = asdict(s)
    return d


def _dict_to_session(d: dict) -> SessionState:
    ctx = AgentContext(**d["context"])

    ks = None
    if d.get("knowledge_state"):
        ks = KnowledgeState(**d["knowledge_state"])

    lp = None
    if d.get("learning_path"):
        lp_data = d["learning_path"]
        steps = [LearningStep(**s) for s in lp_data.get("steps", [])]
        lp = LearningPath(
            path_summary=lp_data["path_summary"],
            total_days=lp_data["total_days"],
            steps=steps,
            daily_schedule=lp_data.get("daily_schedule", {}),
            motivation_message=lp_data.get("motivation_message", "加油！")
        )

    feedback_history = []
    for fr in d.get("feedback_history", []):
        records = [AnswerRecord(**r) for r in fr.get("answer_records", [])]
        feedback_history.append(FeedbackReport(
            topic=fr["topic"],
            summary=fr["summary"],
            error_patterns=fr.get("error_patterns", []),
            mastered_points=fr.get("mastered_points", []),
            weak_points=fr.get("weak_points", []),
            next_action=fr.get("next_action", ""),
            next_topics=fr.get("next_topics", []),
            overall_feedback=fr.get("overall_feedback", ""),
            star_rating=fr.get("star_rating", 3),
            answer_records=records
        ))

    return SessionState(
        session_id=d["session_id"],
        context=ctx,
        knowledge_state=ks,
        learning_path=lp,
        completed_topics=d.get("completed_topics", []),
        feedback_history=feedback_history,
        created_at=d.get("created_at", ""),
        updated_at=d.get("updated_at", "")
    )
