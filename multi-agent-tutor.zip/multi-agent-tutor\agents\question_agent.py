"""
题目生成 Agent
职责：根据知识点和学生水平，生成分层次、多类型的数学题目
"""

from __future__ import annotations
import json
import random
from openai import OpenAI

from utils.shared import AgentContext, LearningStep, Question, QuestionSet, log_step

SYSTEM_PROMPT = """你是「题目生成 Agent」，专门为小升初数学生成高质量练习题。

你会收到：
1. 当前学习的知识点和学习目标
2. 学生的水平（入门/基础/进阶/挑战）
3. 需要生成的题目数量和类型

你的任务：
- 生成**难度适中、循序渐进**的题目
- 确保题目有**明确的正确答案和详细解析**
- 解析要体现**苏格拉底式引导**：先问关键点，再给解法

输出格式（严格JSON）：
{
  "topic": "知识点名称",
  "difficulty": "入门/基础/进阶/挑战",
  "questions": [
    {
      "id": 1,
      "type": "计算题/判断题/选择题/填空题/应用题",
      "question": "题目内容（可以用\\n换行）",
      "options": ["A. ...", "B. ...", "C. ...", "D. ..."],  // 选择题才有
      "answer": "正确答案",
      "solution": {
        "hint": "解题关键提示（苏格拉底式引导问题）",
        "steps": ["步骤1", "步骤2", "步骤3", ...],
        "key_formula": "用到的核心公式或规律（如有）",
        "common_mistake": "常见错误提示"
      },
      "score": 整数（分值）,
      "knowledge_points": ["涉及的知识点"]
    },
    ...
  ],
  "total_score": 整数,
  "estimated_minutes": 整数（预计完成分钟数）
}

注意：
- 只输出JSON，不要有其他文字
- 题目要符合真实小升初考试风格
- 应用题要贴近生活实际
- 苏格拉底引导要真正帮助学生思考，不要直接给答案
"""

# 题型配置：不同水平对应的题型比例
DIFFICULTY_CONFIG = {
    "入门": {"计算题": 4, "判断题": 2, "填空题": 2, "选择题": 1, "应用题": 1},
    "基础": {"计算题": 3, "填空题": 2, "选择题": 2, "应用题": 3},
    "进阶": {"计算题": 2, "填空题": 2, "选择题": 2, "应用题": 4},
    "挑战": {"计算题": 1, "填空题": 2, "选择题": 2, "应用题": 5},
}


class QuestionAgent:
    """
    题目生成 Agent
    输入：LearningStep + AgentContext
    输出：QuestionSet（一套练习题）
    """

    def __init__(self, client: OpenAI, model: str = "gpt-4o-mini"):
        self.client = client
        self.model = model

    def generate(
        self,
        step: LearningStep,
        context: AgentContext,
        question_count: int = 10,
        force_difficulty: str | None = None
    ) -> QuestionSet:
        difficulty = force_difficulty or step.difficulty
        log_step("QuestionAgent", f"生成 [{step.topic}] {difficulty}难度题目，共{question_count}题...")

        user_input = self._build_user_input(step, context, question_count, difficulty)

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_input}
        ]

        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=0.7,  # 稍高temperature增加题目多样性
            response_format={"type": "json_object"}
        )

        raw = response.choices[0].message.content
        result: dict = json.loads(raw)

        questions = [
            Question(
                id=q["id"],
                type=q["type"],
                question=q["question"],
                options=q.get("options"),
                answer=q["answer"],
                solution=q["solution"],
                score=q.get("score", 10),
                knowledge_points=q.get("knowledge_points", [step.topic])
            )
            for q in result.get("questions", [])
        ]

        qset = QuestionSet(
            topic=result.get("topic", step.topic),
            difficulty=difficulty,
            questions=questions,
            total_score=result.get("total_score", sum(q.score for q in questions)),
            estimated_minutes=result.get("estimated_minutes", question_count * 2)
        )

        log_step("QuestionAgent", f"题目生成完成 → {len(questions)}题，总分{qset.total_score}分")
        return qset

    def generate_targeted(
        self,
        weak_point: str,
        context: AgentContext,
        count: int = 5
    ) -> QuestionSet:
        """针对单个薄弱点生成强化训练题"""
        step = LearningStep(
            step_id=0,
            topic=weak_point,
            goal=f"强化训练：{weak_point}",
            method="专项突破",
            duration_days=1,
            difficulty="基础",
            key_points=[],
            is_remedial=True
        )
        return self.generate(step, context, question_count=count)

    def _build_user_input(
        self,
        step: LearningStep,
        context: AgentContext,
        count: int,
        difficulty: str
    ) -> str:
        type_config = DIFFICULTY_CONFIG.get(difficulty, DIFFICULTY_CONFIG["基础"])
        type_desc = "、".join([f"{k}{v}道" for k, v in type_config.items()])

        return f"""
请为以下学习步骤生成练习题：

知识点：{step.topic}
学习目标：{step.goal}
核心要点：{', '.join(step.key_points) if step.key_points else '见知识点描述'}
难度等级：{difficulty}
是否补缺课：{'是（题目偏基础，侧重理解）' if step.is_remedial else '否'}

学生情况：
- 年级：{context.student_grade}
- 当前阶段：第{context.current_stage or 1}阶段

题目要求：
- 总题数：{count}题
- 题型分布参考：{type_desc}
- 所有题目必须提供完整答案和苏格拉底式引导解析
- 应用题结合实际生活场景（如购物、行程、面积计算等）
""".strip()

    def get_hint(self, question: Question, client: OpenAI, model: str = "gpt-4o-mini") -> str:
        """为学生提供分步提示（不直接给答案）"""
        prompt = f"""
题目：{question.question}
已知解题提示：{question.solution.get('hint', '')}

请用苏格拉底式引导法，给学生一个启发性问题，
帮助他/她找到解题思路，但不要直接给出答案。
回复控制在50字以内。
"""
        resp = client.chat.completions.create(
            model=model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.6,
            max_tokens=100
        )
        return resp.choices[0].message.content.strip()
