# 小升初数学 AI 学习助手
> 多 Agent 协作 · 长链推理 · 个性化学习

---

## 🏗️ 系统架构

```
用户输入
    │
    ▼
┌─────────────────────────────────────────────────┐
│               Orchestrator（main.py）            │
│  协调四个子Agent，驱动长链推理                   │
└────┬────────────┬────────────┬──────────────────┘
     │            │            │            │
     ▼            ▼            ▼            ▼
KnowledgeAgent  PathAgent  QuestionAgent  FeedbackAgent
 知识诊断       路径规划    题目生成       反馈评估
```

### 长链推理流程

```
[学生信息] → KnowledgeAgent → [知识状态]
                                   │
                                   ▼
                           PathAgent → [学习路径]
                                           │
                    ┌──────────────────────┘
                    │  FOR 每个学习步骤：
                    │
                    ├→ QuestionAgent → [练习题组]
                    │                      │
                    │              [学生作答]
                    │                      │
                    ├→ FeedbackAgent → [批改报告]
                    │                      │
                    │    正确率 ≥ 70%?
                    │    是 → 下一步骤
                    │    否 → 重新生成题目（最多2次）
                    │
                    └── [最终学习总结]
```

---

## 📁 文件结构

```
multi-agent-tutor/
├── main.py                    # 主协调器（入口）
├── requirements.txt
├── .env.example               # 环境变量示例
│
├── agents/
│   ├── knowledge_agent.py     # 知识图谱Agent：诊断薄弱点
│   ├── path_agent.py          # 路径规划Agent：生成学习计划
│   ├── question_agent.py      # 题目生成Agent：出题、提示
│   └── feedback_agent.py      # 反馈评估Agent：批改、报告
│
├── utils/
│   ├── shared.py              # 共享数据结构（dataclasses）
│   └── session_store.py       # 会话持久化（JSON）
│
└── data/                      # 学习数据存储（自动创建）
    └── session_<id>.json
```

---

## 🚀 快速开始

### 1. 安装依赖

```bash
cd multi-agent-tutor
pip install -r requirements.txt
```

### 2. 配置 API Key

```bash
# 复制配置文件
cp .env.example .env
# 编辑 .env，填入你的 API Key
```

**支持的 API：**
- OpenAI（gpt-4o-mini / gpt-4o）
- DeepSeek（`OPENAI_BASE_URL=https://api.deepseek.com/v1`）
- 通义千问（阿里云兼容模式）
- 月之暗面 Kimi 等兼容 OpenAI 格式的接口

### 3. 运行

```bash
# 完整交互模式
python main.py

# 继续上次学习
python main.py --session <session_id>

# 查看所有会话
python main.py --list

# 演示模式（自动作答，快速查看效果）
python main.py --demo

# 指定模型
python main.py --model gpt-4o
```

---

## 🤖 各 Agent 说明

### KnowledgeAgent（知识图谱 Agent）
- 内置 **20个知识点**的依赖图谱（覆盖小升初全部考点）
- 根据学生描述+答题历史，**识别薄弱点和根本原因**
- 输出结构化知识状态，驱动后续规划

### PathAgent（路径规划 Agent）
- 基于知识状态，生成 **5-12步** 个性化学习路径
- 优先安排**补缺课**（修复根因），再攻核心知识点
- 按每日可用时间合理分配学习节奏

### QuestionAgent（题目生成 Agent）
- 支持：计算题、判断题、选择题、填空题、**应用题**
- 四级难度：入门 / 基础 / 进阶 / 挑战
- 每题含**苏格拉底式引导解析**（先启发，再解法）
- 支持实时提示（输入 `?` 获取引导）

### FeedbackAgent（反馈评估 Agent）
- 精准批改（支持等价写法，如 1/2 = 0.5）
- **错误模式分析**：概念错误/计算错误/审题错误/方法错误
- 生成带**星级评分**的综合学习报告
- 支持**多轮追问**（对不懂的题目继续提问）
- ≥70% 正确率自动进入下一步，否则重新练习

---

## 📊 数据流示意

```python
# 1. 知识诊断
context = AgentContext(
    student_description="分数不太好，应用题经常不知道怎么列算式"
)
knowledge_state = knowledge_agent.diagnose(context)
# → weak_points: ["分数四则运算", "方程应用题"]
# → root_causes: ["分数进阶", "简易方程"]

# 2. 路径规划
path = path_agent.plan(context, knowledge_state)
# → steps: [补缺:分数进阶, 核心:分数四则运算, 核心:简易方程, ...]

# 3. 题目生成
question_set = question_agent.generate(path.steps[0], context)
# → 8道题，含计算题/选择题/应用题

# 4. 批改反馈
records = feedback_agent.batch_grade(question_set, student_answers)
report = feedback_agent.generate_report(question_set, records, context)
# → 正确率75% → ⭐⭐⭐⭐ → 进入下一步
```

---

## 🔧 扩展建议

- **接入微信小程序**：将 main.py 改造为 FastAPI 后端，对接小程序前端
- **语音输入**：集成 Whisper API，支持口头作答
- **图片识别**：支持拍照上传手写答案（GPT-4o Vision）
- **家长报告**：每周自动生成学习周报，微信推送

---

## 📝 开发背景

本项目用于展示：
1. **核心痛点**：家长无法系统辅导，孩子缺乏针对性练习
2. **多 Agent 协作**：4个专职 Agent 分工明确，通过协调器串联
3. **长链推理**：知识点 → 学习路径 → 题目 → 反馈 → 迭代优化
4. **个性化闭环**：每次练习结果反哺知识状态，动态调整路径
