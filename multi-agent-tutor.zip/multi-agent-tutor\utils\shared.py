"""
共享数据结构（所有 Agent 通用）
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Optional
import datetime


# ─── 输入上下文 ───────────────────────────────

@dataclass
class AgentContext:
    """整个多Agent系统的输入上下文"""
    student_grade: str = "小学六年级"
    student_description: str = ""          # 学生自述（如"分数不太好"）
    learning_goal: str = "备战小升初考试"
    daily_minutes: int = 60                # 每天学习分钟数
    days_until_exam: Optional[int] = None  # 距考试天数
    current_stage: Optional[int] = 1       # 当前学习阶段
    answer_history: list[dict] = field(default_factory=list)  # 历史答题记录


# ─── 知识状态 ─────────────────────────────────

@dataclass
class KnowledgeState:
    """知识诊断结果"""
    weak_points: list[str] = field(default_factory=list)
    strong_points: list[str] = field(default_factory=list)
    root_causes: list[str] = field(default_factory=list)
    diagnosis_reason: str = ""
    priority_order: list[str] = field(default_factory=list)
    all_nodes: list[str] = field(default_factory=list)


# ─── 学习路径 ─────────────────────────────────

@dataclass
class LearningStep:
    """单个学习步骤"""
    step_id: int
    topic: str
    goal: str
    method: str
    duration_days: int
    difficulty: str
    key_points: list[str] = field(default_factory=list)
    is_remedial: bool = False


@dataclass
class LearningPath:
    """完整学习路径"""
    path_summary: str
    total_days: int
    steps: list[LearningStep]
    daily_schedule: dict[str, int] = field(default_factory=dict)
    motivation_message: str = "加油！"


# ─── 题目 ─────────────────────────────────────

@dataclass
class Question:
    """单道题目"""
    id: int
    type: str
    question: str
    answer: str
    solution: dict[str, Any]
    score: int = 10
    options: Optional[list[str]] = None
    knowledge_points: list[str] = field(default_factory=list)


@dataclass
class QuestionSet:
    """一套题目"""
    topic: str
    difficulty: str
    questions: list[Question]
    total_score: int = 0
    estimated_minutes: int = 20


# ─── 答题记录 ─────────────────────────────────

@dataclass
class StudentAnswer:
    """学生的单题作答"""
    question_id: int
    answer: str


@dataclass
class AnswerRecord:
    """批改后的答题记录"""
    question_id: int
    question_text: str
    student_answer: str
    correct_answer: str
    is_correct: bool
    score_earned: int
    error_type: str = "无"
    error_detail: str = ""
    correction: str = ""
    feedback_message: str = ""
    next_suggestion: str = ""


# ─── 反馈报告 ─────────────────────────────────

@dataclass
class FeedbackReport:
    """综合学习反馈报告"""
    topic: str
    summary: dict[str, Any]
    error_patterns: list[dict]
    mastered_points: list[str]
    weak_points: list[str]
    next_action: str
    next_topics: list[str]
    overall_feedback: str
    star_rating: int
    answer_records: list[AnswerRecord] = field(default_factory=list)


# ─── Session 状态 ─────────────────────────────

@dataclass
class SessionState:
    """完整学习会话状态（持久化用）"""
    session_id: str
    context: AgentContext
    knowledge_state: Optional[KnowledgeState] = None
    learning_path: Optional[LearningPath] = None
    completed_topics: list[str] = field(default_factory=list)
    feedback_history: list[FeedbackReport] = field(default_factory=list)
    created_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())
    updated_at: str = field(default_factory=lambda: datetime.datetime.now().isoformat())


# ─── 工具函数 ─────────────────────────────────

def log_step(agent_name: str, message: str) -> None:
    """统一日志格式"""
    now = datetime.datetime.now().strftime("%H:%M:%S")
    print(f"\033[36m[{now}]\033[0m \033[33m[{agent_name}]\033[0m {message}")


def format_report(report: FeedbackReport) -> str:
    """将FeedbackReport格式化为可读文本"""
    summary = report.summary
    stars = "⭐" * report.star_rating + "☆" * (5 - report.star_rating)

    lines = [
        f"\n{'=' * 50}",
        f"📊 学习报告：{report.topic}",
        f"{'=' * 50}",
        f"评级：{stars}  ({summary.get('performance_level', '?')})",
        f"得分：{summary.get('score_earned', 0)} / {summary.get('total_score', 0)} 分",
        f"正确：{summary.get('correct_count', 0)} / {summary.get('total_questions', 0)} 题",
        f"正确率：{summary.get('accuracy_rate', 0):.1%}",
        "",
        f"💬 综合评价：",
        f"   {report.overall_feedback}",
    ]

    if report.error_patterns:
        lines.append("\n🔍 发现的问题：")
        for pat in report.error_patterns:
            lines.append(f"   • {pat['pattern']} (出现{pat['frequency']}次)")
            lines.append(f"     ➡ {pat['remedy']}")

    if report.mastered_points:
        lines.append(f"\n✅ 已掌握：{', '.join(report.mastered_points)}")

    if report.weak_points:
        lines.append(f"⚠️  需加强：{', '.join(report.weak_points)}")

    lines.extend([
        f"\n🎯 下一步建议：{report.next_action}",
        f"{'=' * 50}\n"
    ])

    return "\n".join(lines)


def format_question(q: Question, show_answer: bool = False) -> str:
    """格式化单道题目"""
    lines = [f"\n第{q.id}题 [{q.type}] ({q.score}分)"]
    lines.append(q.question)

    if q.options:
        for opt in q.options:
            lines.append(f"  {opt}")

    if show_answer:
        lines.append(f"\n答案：{q.answer}")
        if q.solution:
            lines.append(f"解析提示：{q.solution.get('hint', '')}")
            for i, step in enumerate(q.solution.get("steps", []), 1):
                lines.append(f"  步骤{i}：{step}")

    return "\n".join(lines)
