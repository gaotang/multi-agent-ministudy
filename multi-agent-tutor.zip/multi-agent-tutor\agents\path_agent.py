"""
学习路径规划 Agent
职责：基于知识状态，生成个性化学习路径（含每日计划、学习策略、预计时长）
"""

from __future__ import annotations
import json
from openai import OpenAI

from utils.shared import AgentContext, KnowledgeState, LearningPath, LearningStep, log_step

SYSTEM_PROMPT = """你是「学习路径规划 Agent」，为小升初数学学生制定个性化学习方案。

你会收到：
1. 学生的知识状态（薄弱点、强项、根本原因）
2. 学习目标和可用时间

你的任务：
- 运用**长链推理**：薄弱点 → 前置知识补缺 → 核心知识攻克 → 应用训练 → 综合巩固
- 设计**分步学习路径**，每步有明确目标、方法和时长
- 优先修复根本薄弱点，再攻克目标知识点
- 考虑学生的学习节奏，不要过于激进

输出格式（严格JSON）：
{
  "path_summary": "整体学习路径说明（2-3句话）",
  "total_days": 整数（预计总天数）,
  "steps": [
    {
      "step_id": 1,
      "topic": "知识点名称",
      "goal": "本步骤学习目标",
      "method": "学习方法（如：概念理解+例题精讲+专项练习）",
      "duration_days": 整数,
      "difficulty": "入门/基础/进阶/挑战",
      "key_points": ["要点1", "要点2", ...],
      "is_remedial": true/false  // 是否为补缺课
    },
    ...
  ],
  "daily_schedule": {
    "theory_minutes": 整数,     // 每天理论学习分钟数
    "practice_minutes": 整数,   // 每天练习分钟数
    "review_minutes": 整数      // 每天复习分钟数
  },
  "motivation_message": "给学生的鼓励话语"
}

注意：
- 只输出JSON，不要有其他文字
- steps 数量控制在 5-12 个
- 补缺课（is_remedial=true）优先排在前面
- 每步 duration_days 要合理（1-5天为宜）
"""


class PathAgent:
    """
    学习路径规划 Agent
    输入：KnowledgeState + AgentContext
    输出：LearningPath（个性化学习计划）
    """

    def __init__(self, client: OpenAI, model: str = "gpt-4o-mini"):
        self.client = client
        self.model = model

    def plan(self, context: AgentContext, knowledge_state: KnowledgeState) -> LearningPath:
        log_step("PathAgent", "开始规划个性化学习路径...")

        user_input = self._build_user_input(context, knowledge_state)

        messages = [
            {"role": "system", "content": SYSTEM_PROMPT},
            {"role": "user", "content": user_input}
        ]

        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=0.5,
            response_format={"type": "json_object"}
        )

        raw = response.choices[0].message.content
        result: dict = json.loads(raw)

        steps = [
            LearningStep(
                step_id=s["step_id"],
                topic=s["topic"],
                goal=s["goal"],
                method=s["method"],
                duration_days=s["duration_days"],
                difficulty=s["difficulty"],
                key_points=s.get("key_points", []),
                is_remedial=s.get("is_remedial", False)
            )
            for s in result.get("steps", [])
        ]

        path = LearningPath(
            path_summary=result.get("path_summary", ""),
            total_days=result.get("total_days", 0),
            steps=steps,
            daily_schedule=result.get("daily_schedule", {}),
            motivation_message=result.get("motivation_message", "加油！")
        )

        log_step("PathAgent", f"路径规划完成 → {len(steps)} 个学习步骤，共 {path.total_days} 天")
        return path

    def _build_user_input(self, context: AgentContext, state: KnowledgeState) -> str:
        return f"""
学生信息：
- 年级：{context.student_grade}
- 学习目标：{context.learning_goal or '备战小升初考试'}
- 每天可学习时间：{context.daily_minutes} 分钟
- 距离考试剩余天数：{context.days_until_exam or '未知'}

知识状态诊断结果：
- 薄弱知识点：{', '.join(state.weak_points) if state.weak_points else '暂无明显薄弱点'}
- 根本原因（需补缺）：{', '.join(state.root_causes) if state.root_causes else '无'}
- 已掌握知识点：{', '.join(state.strong_points[:5]) if state.strong_points else '未知'}
- 诊断分析：{state.diagnosis_reason}
- 优先学习顺序：{' → '.join(state.priority_order[:8]) if state.priority_order else '按课程顺序'}

请根据以上信息，制定详细的个性化学习路径。
""".strip()

    def get_current_step(self, path: LearningPath, completed_topics: list[str]) -> LearningStep | None:
        """获取当前应学习的步骤"""
        for step in path.steps:
            if step.topic not in completed_topics:
                return step
        return None  # 全部完成
