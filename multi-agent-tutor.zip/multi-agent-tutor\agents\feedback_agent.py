"""
反馈评估 Agent
职责：批改答案、分析错误模式、生成个性化反馈报告、决定是否进入下一步
"""

from __future__ import annotations
import json
from openai import OpenAI

from utils.shared import (
    AgentContext, QuestionSet, Question,
    StudentAnswer, FeedbackReport, AnswerRecord,
    log_step
)

GRADING_PROMPT = """你是「反馈评估 Agent」，负责批改小升初数学题目并给出深度反馈。

你会收到：
1. 题目内容和标准答案
2. 学生的作答

你的任务：
- **精准判断**答案是否正确（考虑等价写法，如 1/2 和 0.5）
- **分析错误类型**：概念错误/计算错误/审题错误/方法错误
- 生成**温暖鼓励+精准指导**的反馈

输出格式（严格JSON）：
{
  "is_correct": true/false,
  "score_earned": 整数,
  "error_type": "无/概念错误/计算错误/审题错误/方法错误",
  "error_detail": "具体错误描述（如果答错）",
  "correction": "正确解法的关键步骤（如果答错）",
  "feedback_message": "给学生的反馈（温暖、具体、有建设性，2-3句话）",
  "next_suggestion": "下一步建议（如：重新看概念/多练计算/继续下一题）"
}
"""

REPORT_PROMPT = """你是「学习报告 Agent」，分析一组答题数据，生成综合反馈报告。

你的任务：
1. 分析整体表现（得分率、正确题数等）
2. **识别错误模式**（哪类题型/知识点总是错？）
3. 给出**下一步学习建议**
4. 生成鼓励性总结

输出格式（严格JSON）：
{
  "summary": {
    "total_questions": 整数,
    "correct_count": 整数,
    "score_earned": 整数,
    "total_score": 整数,
    "accuracy_rate": 浮点数(0-1),
    "performance_level": "优秀/良好/及格/需加强"
  },
  "error_patterns": [
    {
      "pattern": "错误模式描述",
      "affected_topics": ["知识点"],
      "frequency": 整数,
      "remedy": "针对性建议"
    }
  ],
  "mastered_points": ["已掌握的知识点"],
  "weak_points": ["需要加强的知识点"],
  "next_action": "进入下一步/重复本步骤/针对性补缺",
  "next_topics": ["建议接下来学习的知识点"],
  "overall_feedback": "综合评价（温暖、具体、激励性，3-4句话）",
  "star_rating": 整数(1-5)
}
"""


class FeedbackAgent:
    """
    反馈评估 Agent
    输入：QuestionSet + 学生答案列表
    输出：FeedbackReport（详细反馈报告）
    """

    def __init__(self, client: OpenAI, model: str = "gpt-4o-mini"):
        self.client = client
        self.model = model

    def grade_question(self, question: Question, student_answer: str) -> AnswerRecord:
        """批改单道题"""
        user_input = f"""
题目类型：{question.type}
题目内容：{question.question}
{'选项：' + chr(10).join(question.options) if question.options else ''}
标准答案：{question.answer}
学生答案：{student_answer}
题目分值：{question.score}分
"""
        messages = [
            {"role": "system", "content": GRADING_PROMPT},
            {"role": "user", "content": user_input}
        ]

        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=0.2,
            response_format={"type": "json_object"}
        )

        result = json.loads(response.choices[0].message.content)

        return AnswerRecord(
            question_id=question.id,
            question_text=question.question,
            student_answer=student_answer,
            correct_answer=question.answer,
            is_correct=result.get("is_correct", False),
            score_earned=result.get("score_earned", 0),
            error_type=result.get("error_type", "无"),
            error_detail=result.get("error_detail", ""),
            correction=result.get("correction", ""),
            feedback_message=result.get("feedback_message", ""),
            next_suggestion=result.get("next_suggestion", "继续努力")
        )

    def batch_grade(
        self,
        question_set: QuestionSet,
        student_answers: list[StudentAnswer]
    ) -> list[AnswerRecord]:
        """批量批改一套题"""
        log_step("FeedbackAgent", f"开始批改 {len(student_answers)} 道题...")

        # 构建答案映射
        answer_map = {sa.question_id: sa.answer for sa in student_answers}
        records = []

        for question in question_set.questions:
            student_ans = answer_map.get(question.id, "（未作答）")
            record = self.grade_question(question, student_ans)
            records.append(record)

        log_step("FeedbackAgent", f"批改完成 → 正确{sum(1 for r in records if r.is_correct)}题")
        return records

    def generate_report(
        self,
        question_set: QuestionSet,
        records: list[AnswerRecord],
        context: AgentContext
    ) -> FeedbackReport:
        """生成综合学习反馈报告"""
        log_step("FeedbackAgent", "生成综合反馈报告...")

        # 构建答题详情
        details = []
        for r in records:
            details.append({
                "题号": r.question_id,
                "是否正确": r.is_correct,
                "得分": r.score_earned,
                "错误类型": r.error_type,
                "错误详情": r.error_detail,
                "知识点": r.question_text[:30] + "..."
            })

        user_input = f"""
学生信息：{context.student_grade}，当前学习：{question_set.topic}
难度等级：{question_set.difficulty}

答题情况：
{json.dumps(details, ensure_ascii=False, indent=2)}

题目总分：{question_set.total_score}分
实际得分：{sum(r.score_earned for r in records)}分
"""

        messages = [
            {"role": "system", "content": REPORT_PROMPT},
            {"role": "user", "content": user_input}
        ]

        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=0.4,
            response_format={"type": "json_object"}
        )

        result = json.loads(response.choices[0].message.content)

        report = FeedbackReport(
            topic=question_set.topic,
            summary=result.get("summary", {}),
            error_patterns=result.get("error_patterns", []),
            mastered_points=result.get("mastered_points", []),
            weak_points=result.get("weak_points", []),
            next_action=result.get("next_action", "进入下一步"),
            next_topics=result.get("next_topics", []),
            overall_feedback=result.get("overall_feedback", ""),
            star_rating=result.get("star_rating", 3),
            answer_records=records
        )

        log_step(
            "FeedbackAgent",
            f"报告生成 → {report.summary.get('performance_level', '?')} | "
            f"{'⭐' * report.star_rating} | 建议：{report.next_action}"
        )
        return report

    def should_advance(self, report: FeedbackReport, threshold: float = 0.7) -> bool:
        """判断是否应该进入下一学习步骤"""
        accuracy = report.summary.get("accuracy_rate", 0)
        return accuracy >= threshold

    def interactive_feedback(
        self,
        question: Question,
        student_answer: str,
        follow_up: str,
        client: OpenAI
    ) -> str:
        """多轮对话式反馈：学生可以追问"""
        prompt = f"""
题目：{question.question}
标准答案：{question.answer}
学生答案：{student_answer}
解析：{json.dumps(question.solution, ensure_ascii=False)}

学生的追问：{follow_up}

请用苏格拉底式对话，循循善诱地回答学生的问题，
帮助他/她理解，不要直接背诵标准答案。
语气温和，适合小学高年级学生。
回复在100字以内。
"""
        resp = client.chat.completions.create(
            model=self.model,
            messages=[{"role": "user", "content": prompt}],
            temperature=0.7,
            max_tokens=200
        )
        return resp.choices[0].message.content.strip()
