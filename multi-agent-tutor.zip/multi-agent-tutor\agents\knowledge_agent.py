"""
知识图谱 Agent
职责：维护小升初数学知识点图谱，诊断学生薄弱环节，输出结构化知识状态
"""

from __future__ import annotations
import json
from typing import Any
from openai import OpenAI

from utils.shared import AgentContext, KnowledgeState, log_step

# ───────────────────────────────────────────
# 知识图谱：节点 = 知识点，边 = 依赖关系
# ───────────────────────────────────────────
KNOWLEDGE_GRAPH: dict[str, dict] = {
    "整数概念": {
        "stage": 1, "depends": [],
        "desc": "整数的意义、正负数、数轴、绝对值"
    },
    "小数概念": {
        "stage": 1, "depends": ["整数概念"],
        "desc": "小数的意义、小数的读写、小数的性质"
    },
    "分数概念": {
        "stage": 1, "depends": ["整数概念"],
        "desc": "分数的意义、分数与除法的关系、分数的基本性质"
    },
    "四则运算": {
        "stage": 1, "depends": ["整数概念", "小数概念", "分数概念"],
        "desc": "加减乘除法则、运算律（交换律、结合律、分配律）"
    },
    "整除性": {
        "stage": 1, "depends": ["整数概念"],
        "desc": "因数与倍数、质数合数、2/3/5/9倍数特征"
    },
    "最大公因数_最小公倍数": {
        "stage": 1, "depends": ["整除性"],
        "desc": "求最大公因数（短除法）、最小公倍数"
    },
    "分数进阶": {
        "stage": 2, "depends": ["分数概念", "最大公因数_最小公倍数"],
        "desc": "约分、通分、分数与小数互化、循环小数"
    },
    "分数四则运算": {
        "stage": 2, "depends": ["分数进阶", "四则运算"],
        "desc": "分数混合运算、简便运算"
    },
    "比和比例": {
        "stage": 3, "depends": ["分数四则运算"],
        "desc": "比的意义与性质、比例的意义、正反比例、比例尺"
    },
    "按比分配": {
        "stage": 3, "depends": ["比和比例"],
        "desc": "按比例分配问题解法"
    },
    "简易方程": {
        "stage": 4, "depends": ["四则运算", "比和比例"],
        "desc": "用字母表示数、等式性质、解一元一次方程"
    },
    "方程应用题": {
        "stage": 4, "depends": ["简易方程"],
        "desc": "列方程解应用题、建模思维"
    },
    "平面图形": {
        "stage": 5, "depends": ["整数概念"],
        "desc": "三角形、四边形、圆的周长面积公式"
    },
    "立体图形": {
        "stage": 5, "depends": ["平面图形"],
        "desc": "长方体、正方体、圆柱、圆锥的表面积与体积"
    },
    "统计": {
        "stage": 6, "depends": ["四则运算"],
        "desc": "统计表、条形/折线/扇形图、平均数中位数众数"
    },
    "概率": {
        "stage": 6, "depends": ["统计"],
        "desc": "简单事件的可能性"
    },
    "行程问题": {
        "stage": 7, "depends": ["四则运算", "简易方程"],
        "desc": "相遇问题、追及问题、流水行船"
    },
    "工程问题": {
        "stage": 7, "depends": ["分数四则运算", "简易方程"],
        "desc": "工程问题建模与求解"
    },
    "浓度问题": {
        "stage": 7, "depends": ["百分数", "简易方程"],
        "desc": "溶液的浓度计算"
    },
    "百分数": {
        "stage": 2, "depends": ["分数进阶"],
        "desc": "百分数的意义、与分数小数互化、百分数应用"
    },
    "经济问题": {
        "stage": 7, "depends": ["百分数", "简易方程"],
        "desc": "利润、折扣、税率相关计算"
    },
    "鸡兔同笼": {
        "stage": 7, "depends": ["简易方程"],
        "desc": "鸡兔同笼及变型题"
    },
}

SYSTEM_PROMPT = """你是「知识诊断 Agent」，专门分析小升初数学学习状态。

你的任务：
1. 根据学生描述或答题记录，**精准识别薄弱知识点**
2. 基于知识依赖图谱，**推断根本原因**（是因为前置知识不扎实导致的？）
3. 输出结构化的知识状态报告

知识图谱信息如下（JSON格式）：
{graph}

输出格式（严格JSON）：
{{
  "weak_points": ["知识点名称", ...],        // 当前薄弱知识点
  "root_causes": ["知识点名称", ...],        // 深层根本原因知识点
  "strong_points": ["知识点名称", ...],      // 已掌握的知识点
  "diagnosis_reason": "一段简短的诊断分析",
  "priority_order": ["按学习优先级排列的知识点", ...]
}}

注意：
- 只输出JSON，不要有任何其他文字
- weak_points 优先列出当前阶段的
- root_causes 追溯到依赖链上的根本薄弱点
"""


class KnowledgeAgent:
    """
    知识图谱 Agent
    输入：学生背景描述 + 历史答题记录
    输出：KnowledgeState（结构化知识状态）
    """

    def __init__(self, client: OpenAI, model: str = "gpt-4o-mini"):
        self.client = client
        self.model = model
        self.graph = KNOWLEDGE_GRAPH

    def diagnose(self, context: AgentContext) -> KnowledgeState:
        log_step("KnowledgeAgent", "开始知识点诊断分析...")

        # 构建用户输入
        user_input = self._build_user_input(context)

        messages = [
            {
                "role": "system",
                "content": SYSTEM_PROMPT.format(
                    graph=json.dumps(self.graph, ensure_ascii=False, indent=2)
                )
            },
            {"role": "user", "content": user_input}
        ]

        response = self.client.chat.completions.create(
            model=self.model,
            messages=messages,
            temperature=0.3,
            response_format={"type": "json_object"}
        )

        raw = response.choices[0].message.content
        result: dict[str, Any] = json.loads(raw)

        state = KnowledgeState(
            weak_points=result.get("weak_points", []),
            strong_points=result.get("strong_points", []),
            root_causes=result.get("root_causes", []),
            diagnosis_reason=result.get("diagnosis_reason", ""),
            priority_order=result.get("priority_order", []),
            all_nodes=list(self.graph.keys())
        )

        log_step("KnowledgeAgent", f"诊断完成 → 薄弱点: {state.weak_points[:3]}...")
        return state

    def _build_user_input(self, context: AgentContext) -> str:
        parts = [f"学生年级：{context.student_grade}"]

        if context.student_description:
            parts.append(f"学生自述：{context.student_description}")

        if context.answer_history:
            parts.append("答题历史：")
            for record in context.answer_history[-10:]:  # 最近10条
                status = "✓" if record.get("correct") else "✗"
                parts.append(
                    f"  {status} [{record.get('topic', '未知')}] {record.get('question', '')[:50]}..."
                )

        if context.current_stage:
            parts.append(f"当前学习阶段：第{context.current_stage}阶段")

        return "\n".join(parts)

    def get_prerequisites(self, topic: str) -> list[str]:
        """获取某知识点的所有前置依赖（递归）"""
        if topic not in self.graph:
            return []
        deps = list(self.graph[topic]["depends"])
        for dep in self.graph[topic]["depends"]:
            deps.extend(self.get_prerequisites(dep))
        return list(dict.fromkeys(deps))  # 去重保序

    def get_topic_info(self, topic: str) -> dict:
        return self.graph.get(topic, {})
