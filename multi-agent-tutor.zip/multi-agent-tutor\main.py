"""
多 Agent 协调器（Orchestrator）
长链推理流程：知识诊断 → 路径规划 → 题目生成 → 答题 → 反馈 → 循环迭代

使用方法：
  python main.py                   # 新建会话，全流程
  python main.py --session <id>    # 继续已有会话
  python main.py --demo            # 演示模式（无需API Key）
"""

from __future__ import annotations
import os
import sys
import argparse
import json
from typing import Optional
from openai import OpenAI

from agents.knowledge_agent import KnowledgeAgent
from agents.path_agent import PathAgent
from agents.question_agent import QuestionAgent
from agents.feedback_agent import FeedbackAgent
from utils.shared import (
    AgentContext, SessionState, StudentAnswer,
    log_step, format_report, format_question
)
from utils.session_store import (
    new_session, save_session, load_session,
    list_sessions, append_answer_history
)

# ─── 配置 ─────────────────────────────────────

DEFAULT_MODEL = os.getenv("OPENAI_MODEL", "gpt-4o-mini")
PASS_THRESHOLD = 0.7   # 达到70%正确率才进入下一步
MAX_RETRY = 2          # 同一知识点最多重试次数


# ─── 主协调器 ─────────────────────────────────

class MultiAgentTutor:
    """
    多 Agent 学习助手协调器

    长链推理链路：
    [用户输入]
        ↓
    KnowledgeAgent  →  知识诊断 & 薄弱点识别
        ↓
    PathAgent       →  个性化学习路径规划
        ↓
    ┌─────────────────────────────────┐  循环每个学习步骤
    │  QuestionAgent → 生成练习题     │
    │       ↓                        │
    │  [学生作答]                     │
    │       ↓                        │
    │  FeedbackAgent → 批改+反馈      │
    │       ↓                        │
    │  ≥70%? → 下一步 | 否 → 重试    │
    └─────────────────────────────────┘
        ↓
    [生成最终学习报告]
    """

    def __init__(self, api_key: str, model: str = DEFAULT_MODEL, base_url: str = None):
        kwargs = {"api_key": api_key}
        if base_url:
            kwargs["base_url"] = base_url

        self.client = OpenAI(**kwargs)
        self.model = model

        # 初始化四个子Agent
        self.knowledge_agent = KnowledgeAgent(self.client, model)
        self.path_agent = PathAgent(self.client, model)
        self.question_agent = QuestionAgent(self.client, model)
        self.feedback_agent = FeedbackAgent(self.client, model)

        self.session: Optional[SessionState] = None

    # ────────────────────────────────────────────
    # 阶段 1：初始化会话
    # ────────────────────────────────────────────
    def start_session(self, context: AgentContext) -> SessionState:
        self.session = new_session(context)
        print(f"\n🎓 新学习会话已创建 | 会话ID: {self.session.session_id}")
        return self.session

    def resume_session(self, session_id: str) -> bool:
        self.session = load_session(session_id)
        if self.session:
            print(f"\n🔄 恢复会话 {session_id}")
            print(f"   已完成：{', '.join(self.session.completed_topics) or '无'}")
            return True
        return False

    # ────────────────────────────────────────────
    # 阶段 2：知识诊断（KnowledgeAgent）
    # ────────────────────────────────────────────
    def run_diagnosis(self) -> None:
        assert self.session, "请先创建或恢复会话"

        print("\n" + "═" * 50)
        print("📋 阶段一：知识点诊断")
        print("═" * 50)

        self.session.knowledge_state = self.knowledge_agent.diagnose(
            self.session.context
        )
        ks = self.session.knowledge_state

        print(f"\n诊断结果：")
        print(f"  🔴 薄弱点：{', '.join(ks.weak_points[:5]) or '暂无'}")
        print(f"  🟡 根因：  {', '.join(ks.root_causes[:3]) or '无'}")
        print(f"  🟢 强项：  {', '.join(ks.strong_points[:3]) or '未知'}")
        print(f"\n  💡 {ks.diagnosis_reason}")

        save_session(self.session)

    # ────────────────────────────────────────────
    # 阶段 3：路径规划（PathAgent）
    # ────────────────────────────────────────────
    def run_path_planning(self) -> None:
        assert self.session and self.session.knowledge_state, "请先完成知识诊断"

        print("\n" + "═" * 50)
        print("🗺️  阶段二：学习路径规划")
        print("═" * 50)

        self.session.learning_path = self.path_agent.plan(
            self.session.context,
            self.session.knowledge_state
        )
        lp = self.session.learning_path

        print(f"\n📅 学习计划（共 {lp.total_days} 天）：")
        print(f"   {lp.path_summary}")
        print()
        for step in lp.steps:
            prefix = "🔧" if step.is_remedial else "📚"
            print(f"   {prefix} 步骤{step.step_id}: [{step.difficulty}] {step.topic}")
            print(f"      目标：{step.goal}")
            print(f"      方法：{step.method}（约{step.duration_days}天）")

        daily = lp.daily_schedule
        print(f"\n⏰ 每日安排：理论{daily.get('theory_minutes', 20)}分 | "
              f"练习{daily.get('practice_minutes', 30)}分 | "
              f"复习{daily.get('review_minutes', 10)}分")
        print(f"\n💪 {lp.motivation_message}")

        save_session(self.session)

    # ────────────────────────────────────────────
    # 阶段 4：学习循环（QuestionAgent + FeedbackAgent）
    # ────────────────────────────────────────────
    def run_learning_loop(self, interactive: bool = True) -> None:
        assert self.session and self.session.learning_path, "请先完成路径规划"
        lp = self.session.learning_path

        print("\n" + "═" * 50)
        print("🔄 阶段三：学习循环")
        print("═" * 50)

        for step in lp.steps:
            if step.topic in self.session.completed_topics:
                print(f"\n✅ 跳过（已完成）：{step.topic}")
                continue

            print(f"\n{'─' * 40}")
            print(f"📖 当前步骤：{step.topic}  [{step.difficulty}]")
            print(f"{'─' * 40}")

            retry_count = 0
            passed = False

            while not passed and retry_count <= MAX_RETRY:
                if retry_count > 0:
                    print(f"\n🔁 第{retry_count}次重试...")

                # 生成题目
                question_set = self.question_agent.generate(
                    step, self.session.context,
                    question_count=8 if retry_count == 0 else 5
                )

                # 展示题目
                if interactive:
                    passed = self._interactive_exercise(step, question_set)
                else:
                    passed = self._auto_exercise(step, question_set)

                retry_count += 1

            if passed:
                self.session.completed_topics.append(step.topic)
                save_session(self.session)
            else:
                print(f"\n⚠️  {step.topic} 已达最大重试次数，建议课后复习")

        self._show_final_summary()

    # ────────────────────────────────────────────
    # 交互式练习
    # ────────────────────────────────────────────
    def _interactive_exercise(self, step, question_set) -> bool:
        print(f"\n📝 共 {len(question_set.questions)} 道题，预计 {question_set.estimated_minutes} 分钟")
        print("   输入答案后回车，输入 '?' 获取提示，输入 'skip' 跳过\n")

        student_answers = []

        for q in question_set.questions:
            print(format_question(q))

            while True:
                ans = input("\n你的答案：").strip()
                if ans == "?":
                    hint = self.question_agent.get_hint(q, self.client, self.model)
                    print(f"💡 提示：{hint}")
                elif ans == "skip":
                    ans = "（跳过）"
                    break
                elif ans:
                    break

            student_answers.append(StudentAnswer(q.id, ans))

            # 实时单题反馈
            record = self.feedback_agent.grade_question(q, ans)
            if record.is_correct:
                print(f"✅ 正确！{record.feedback_message}")
            else:
                print(f"❌ {record.feedback_message}")
                if record.correction:
                    print(f"   解析：{record.correction}")

                # 支持追问
                follow_up = input("\n   有疑问吗？（直接回车跳过）：").strip()
                if follow_up:
                    response = self.feedback_agent.interactive_feedback(
                        q, ans, follow_up, self.client
                    )
                    print(f"   🤔 {response}")

            # 记录到历史
            append_answer_history(
                self.session, step.topic,
                q.question[:50], record.is_correct
            )

        # 生成本次报告
        records = [self.feedback_agent.grade_question(q, sa.answer)
                   for q, sa in zip(question_set.questions, student_answers)]
        report = self.feedback_agent.generate_report(
            question_set, records, self.session.context
        )
        self.session.feedback_history.append(report)

        print(format_report(report))
        return self.feedback_agent.should_advance(report, PASS_THRESHOLD)

    # ────────────────────────────────────────────
    # 自动演示模式（无需用户输入）
    # ────────────────────────────────────────────
    def _auto_exercise(self, step, question_set) -> bool:
        """演示用：自动随机作答"""
        import random
        print(f"\n[自动演示模式] {len(question_set.questions)} 道题...")

        student_answers = []
        for q in question_set.questions:
            # 模拟70-90%正确率
            if random.random() < 0.8:
                ans = q.answer  # 答对
            else:
                ans = "随机错误答案"
            student_answers.append(StudentAnswer(q.id, ans))
            print(f"  题{q.id}: 作答 '{ans[:20]}'")

        records = self.feedback_agent.batch_grade(question_set, student_answers)
        report = self.feedback_agent.generate_report(
            question_set, records, self.session.context
        )
        self.session.feedback_history.append(report)

        print(format_report(report))
        return self.feedback_agent.should_advance(report, PASS_THRESHOLD)

    # ────────────────────────────────────────────
    # 最终总结
    # ────────────────────────────────────────────
    def _show_final_summary(self):
        completed = self.session.completed_topics
        total = len(self.session.learning_path.steps)
        done = len(completed)

        print("\n" + "═" * 50)
        print("🎉 学习阶段总结")
        print("═" * 50)
        print(f"完成进度：{done}/{total} 个知识点")
        print(f"已掌握：{', '.join(completed) or '无'}")

        if self.session.feedback_history:
            avg_accuracy = sum(
                r.summary.get("accuracy_rate", 0)
                for r in self.session.feedback_history
            ) / len(self.session.feedback_history)
            print(f"平均正确率：{avg_accuracy:.1%}")

        print(f"\n📁 会话数据已保存 (ID: {self.session.session_id})")
        print(f"   下次继续：python main.py --session {self.session.session_id}")

    # ────────────────────────────────────────────
    # 完整流程入口
    # ────────────────────────────────────────────
    def run_full_pipeline(
        self,
        context: AgentContext,
        interactive: bool = True
    ) -> SessionState:
        """一键运行完整长链推理流程"""
        self.start_session(context)
        self.run_diagnosis()

        if not _confirm("\n✅ 诊断完成，是否开始规划学习路径？"):
            return self.session

        self.run_path_planning()

        if not _confirm("\n✅ 路径规划完成，是否开始学习？"):
            return self.session

        self.run_learning_loop(interactive=interactive)
        return self.session


# ─── CLI 入口 ──────────────────────────────────

def _confirm(msg: str) -> bool:
    try:
        resp = input(f"{msg} (y/n): ").strip().lower()
        return resp in ("y", "yes", "")
    except EOFError:
        return True


def _collect_context() -> AgentContext:
    """交互式收集学生信息"""
    print("\n📋 学生信息录入（直接回车使用默认值）")
    print("─" * 40)

    grade = input("年级 [小学六年级]: ").strip() or "小学六年级"
    desc = input("学习困难描述（如'分数计算容易出错'）: ").strip()
    goal = input("学习目标 [备战小升初考试]: ").strip() or "备战小升初考试"

    try:
        minutes = int(input("每天可学习分钟数 [60]: ").strip() or "60")
    except ValueError:
        minutes = 60

    try:
        days = input("距考试天数（不确定请回车）: ").strip()
        days = int(days) if days else None
    except ValueError:
        days = None

    return AgentContext(
        student_grade=grade,
        student_description=desc,
        learning_goal=goal,
        daily_minutes=minutes,
        days_until_exam=days,
        current_stage=1
    )


def main():
    parser = argparse.ArgumentParser(description="小升初多Agent AI学习助手")
    parser.add_argument("--session", help="恢复已有会话ID")
    parser.add_argument("--demo", action="store_true", help="演示模式（自动作答）")
    parser.add_argument("--list", action="store_true", help="列出所有会话")
    parser.add_argument("--model", default=DEFAULT_MODEL, help="使用的模型")
    args = parser.parse_args()

    # 列出会话
    if args.list:
        sessions = list_sessions()
        if not sessions:
            print("暂无保存的会话")
        else:
            print(f"\n{'ID':<10} {'更新时间':<25} {'年级':<15} {'已完成'}")
            print("─" * 70)
            for s in sessions:
                completed = ", ".join(s["completed_topics"][:3]) or "无"
                print(f"{s['session_id']:<10} {s['updated_at'][:19]:<25} {s['student']:<15} {completed}")
        return

    # 获取API配置
    api_key = os.getenv("OPENAI_API_KEY")
    base_url = os.getenv("OPENAI_BASE_URL")  # 支持国内代理或其他兼容接口

    if not api_key:
        print("⚠️  未找到 OPENAI_API_KEY 环境变量")
        print("   请设置：export OPENAI_API_KEY=你的key")
        print("   或在 .env 文件中配置")
        if not args.demo:
            sys.exit(1)
        api_key = "demo-key"  # 演示模式使用占位key

    print("\n" + "=" * 50)
    print("  🎓 小升初数学 AI 学习助手")
    print("  多 Agent 协作 · 长链推理 · 个性化学习")
    print("=" * 50)

    tutor = MultiAgentTutor(api_key, model=args.model, base_url=base_url)

    if args.session:
        # 恢复会话
        if not tutor.resume_session(args.session):
            print(f"❌ 找不到会话 {args.session}")
            sys.exit(1)

        # 判断恢复到哪个阶段
        session = tutor.session
        if not session.knowledge_state:
            tutor.run_diagnosis()
        if not session.learning_path:
            tutor.run_path_planning()
        tutor.run_learning_loop(interactive=not args.demo)
    else:
        # 新会话
        context = _collect_context()
        tutor.run_full_pipeline(context, interactive=not args.demo)


if __name__ == "__main__":
    main()
